function calcD(a, b, c) {
return b*b - 4*a*c;
}
document.write(calcD(2, 3, 4));
